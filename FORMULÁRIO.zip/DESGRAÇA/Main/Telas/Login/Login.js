
function verificarLogin() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    const dados = JSON.parse(localStorage.getItem("dados"));


    // Verificar se o usuário existe no array e se a senha bate
    const usuarioEncontrado = dados.find(dados => 
        dados.username === username && dados.password === password
    );

    if (usuarioEncontrado) {
        alert("Login bem-sucedido!");
    } else {
        alert("Usuário ou senha inválidos.");
    }
};


document.getElementById("login-form").addEventListener("submit", function(event) {
    event.preventDefault();
    verificarLogin();
});