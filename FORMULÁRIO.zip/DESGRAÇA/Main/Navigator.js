const navLinks = document.querySelectorAll(".navigation a");

navLinks.forEach(link => {
    link.addEventListener("click", event => {
        event.preventDefault(); // Impede o comportamento padrão do link

        const targetPage = event.target.getAttribute("data-page"); // Pega o valor do atributo data-page

        loadPage(targetPage); // Chama a função para carregar a página correspondente
    });
});

function loadPage(pageName) {
    const container = document.getElementById("content");

    // Faz a requisição da página correspondente (Login ou Cadastro)
    fetch(`Telas/${pageName}/${pageName}.html`)
    .then(response => {
        if (!response.ok) {
            throw new Error(`Erro ao carregar ${pageName}.html`);
        }
        return response.text();
    })
    .then(html => {
        // Insere o HTML da página no container
        container.innerHTML = html;

        // Adiciona o CSS da página correspondente
        const link = document.createElement("link");
        link.rel = "stylesheet";
        link.href = `Telas/${pageName}/${pageName}.css`; 
        document.head.appendChild(link);

        // Adiciona o script da página correspondente
        const script = document.createElement("script");
        script.src = `Telas/${pageName}/${pageName}.js`;
        document.body.appendChild(script);
    })
    .catch(error => console.error(error));
}
